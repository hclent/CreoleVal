Silver-standard Name Annotations From Wikipedia Markups
Xiaoman Pan
panx2@rpi.edu

FORMAT:
[TOKEN] [ADDITIONAL INFORMATION] [TAG]

ADDITIONAL INFORMATION FORMAT:
[Wikipedia title] [name mention] [entity type] [entity type confidence] [English Wikipedia title]

If you would like to cite this work, please cite the following publication:
Cross-lingual Name Tagging and Linking for 282 Languages
